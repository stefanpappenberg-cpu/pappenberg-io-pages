(function () {
  'use strict';

  var hamburger = document.getElementById('js-hamburger');
  var mobileMenu = document.getElementById('js-mobile-menu');
  var overlayTriggers = 0;

  function setGlassOverlay(active) {
    overlayTriggers += active ? 1 : -1;
    overlayTriggers = Math.max(0, overlayTriggers);
    document.body.classList.toggle('has-glass-overlay', overlayTriggers > 0);
  }

  function closeMobileMenu() {
    if (!hamburger || !mobileMenu) return;
    var wasOpen = mobileMenu.classList.contains('is-open');
    mobileMenu.classList.remove('is-open');
    hamburger.setAttribute('aria-expanded', 'false');
    hamburger.setAttribute('aria-label', 'Menü öffnen');
    mobileMenu.setAttribute('aria-hidden', 'true');
    if (wasOpen) setGlassOverlay(false);
  }

  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      var isOpen = mobileMenu.classList.toggle('is-open');
      hamburger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      hamburger.setAttribute('aria-label', isOpen ? 'Menü schließen' : 'Menü öffnen');
      mobileMenu.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
      setGlassOverlay(isOpen);
    });

    mobileMenu.addEventListener('click', function (event) {
      if (event.target.tagName === 'A') closeMobileMenu();
    });
  }

  var modalStage = document.getElementById('js-modal-stage');
  var modal = document.getElementById('js-prototype-modal');
  var modalSwitch = document.getElementById('js-modal-switch');
  var modalTriggers = document.querySelectorAll('[data-modal-open]');
  var modalLoadingTimer = null;
  var lastModalTrigger = null;
  var modalIsOpen = false;

  function setModalLoading(active) {
    if (!modal) return;
    modal.classList.toggle('is-loading', active);
  }

  function openPrototypeModal(trigger) {
    if (!modalStage || !modal || modalIsOpen) return;
    modalIsOpen = true;
    lastModalTrigger = trigger || document.activeElement;
    modalStage.hidden = false;
    modalStage.setAttribute('aria-hidden', 'false');
    modal.classList.remove('is-closing');
    if (modalSwitch) modalSwitch.checked = true;
    setGlassOverlay(true);
    document.body.classList.add('is-modal-locked');
    setModalLoading(true);

    window.requestAnimationFrame(function () {
      modalStage.classList.add('is-open');
      modal.focus({ preventScroll: true });
    });

    window.clearTimeout(modalLoadingTimer);
    modalLoadingTimer = window.setTimeout(function () {
      setModalLoading(false);
    }, reducedMotion ? 0 : 900);
  }

  function closePrototypeModal(options) {
    if (!modalStage || !modal || !modalIsOpen) return;
    var delay = options && options.waitForSwitch ? 380 : 0;

    window.setTimeout(function () {
      modalIsOpen = false;
      window.clearTimeout(modalLoadingTimer);
      setModalLoading(false);
      modal.classList.add('is-closing');
      modalStage.classList.remove('is-open');
      setGlassOverlay(false);
      document.body.classList.remove('is-modal-locked');

      window.setTimeout(function () {
        modalStage.hidden = true;
        modalStage.setAttribute('aria-hidden', 'true');
        modal.classList.remove('is-closing');
        if (modalSwitch) modalSwitch.checked = true;
        if (lastModalTrigger && typeof lastModalTrigger.focus === 'function') {
          lastModalTrigger.focus({ preventScroll: true });
        }
      }, reducedMotion ? 0 : 420);
    }, delay);
  }

  modalTriggers.forEach(function (trigger) {
    trigger.addEventListener('click', function () {
      openPrototypeModal(trigger);
    });
    trigger.addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      event.preventDefault();
      openPrototypeModal(trigger);
    });
  });

  if (modalSwitch) {
    modalSwitch.addEventListener('change', function () {
      if (!modalSwitch.checked) closePrototypeModal({ waitForSwitch: true });
    });
  }

  if (modalStage) {
    modalStage.addEventListener('click', function (event) {
      if (event.target.matches('[data-modal-close]')) closePrototypeModal();
    });
  }

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && modalIsOpen) closePrototypeModal();
  });

  function pulseTarget(hash) {
    if (!hash || hash === '#') return;
    var target;
    try {
      target = document.querySelector(hash);
    } catch (error) {
      return;
    }
    if (!target) return;
    target.classList.remove('content-pulse');
    void target.offsetWidth;
    target.classList.add('content-pulse');
  }

  document.querySelectorAll('a[href^="#"], a[href^="index.html#"]').forEach(function (link) {
    link.addEventListener('click', function () {
      var hash = link.hash;
      window.setTimeout(function () {
        pulseTarget(hash);
      }, 120);
    });
  });

  var nav = document.querySelector('.site-nav');
  function updateNavState() {
    if (!nav) return;
    nav.classList.toggle('is-scrolled', window.scrollY > 12);
  }
  updateNavState();
  window.addEventListener('scroll', updateNavState, { passive: true });

  var revealItems = document.querySelectorAll('.reveal');
  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!reducedMotion) {
    var parallaxFrame = null;

    function updateParallax() {
      parallaxFrame = null;
      var offset = Math.max(-180, Math.min(180, window.scrollY * -0.16));
      document.documentElement.style.setProperty('--parallax-offset', offset.toFixed(1) + 'px');
    }

    function requestParallaxUpdate() {
      if (parallaxFrame !== null) return;
      parallaxFrame = window.requestAnimationFrame(updateParallax);
    }

    updateParallax();
    window.addEventListener('scroll', requestParallaxUpdate, { passive: true });
    window.addEventListener('resize', requestParallaxUpdate);
  }

  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealItems.forEach(function (item) {
      item.classList.add('is-visible');
    });
  } else {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });

    revealItems.forEach(function (item) {
      observer.observe(item);
    });
  }

  var form = document.getElementById('js-contact-form');
  var submitBtn = document.getElementById('js-submit-btn');
  var successMsg = document.getElementById('js-success');

  function validateField(input) {
    var error = document.getElementById('err-' + input.id.replace('field-', ''));
    var valid = input.validity.valid;
    input.classList.toggle('is-invalid', !valid);
    if (error) error.classList.toggle('is-visible', !valid);
    return valid;
  }

  if (form) {
    var requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(function (field) {
      field.addEventListener('blur', function () {
        validateField(field);
      });
      field.addEventListener('input', function () {
        if (field.classList.contains('is-invalid')) validateField(field);
      });
    });

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var valid = Array.from(requiredFields).every(validateField);
      if (!valid) return;

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Anfrage vorbereitet';
      }
      if (successMsg) successMsg.hidden = false;
      form.reset();

      window.setTimeout(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Projekt anfragen';
        }
      }, 1400);
    });
  }

  var year = document.getElementById('js-year');
  if (year) year.textContent = new Date().getFullYear();

  var banner = document.getElementById('js-cookie-banner');
  var accept = document.getElementById('js-cookie-accept');
  var decline = document.getElementById('js-cookie-decline');
  var settings = document.getElementById('js-cookie-settings');
  var storageKey = 'pappenbergCookieConsent';

  function setCookieChoice(choice) {
    try {
      localStorage.setItem(storageKey, choice);
    } catch (error) {
      document.cookie = storageKey + '=' + choice + '; max-age=31536000; path=/; SameSite=Lax';
    }
    if (banner) {
      banner.classList.add('is-closing');
      setGlassOverlay(false);
      window.setTimeout(function () {
        banner.hidden = true;
        banner.classList.remove('is-closing');
      }, reducedMotion ? 0 : 280);
    }
  }

  function hasCookieChoice() {
    try {
      return Boolean(localStorage.getItem(storageKey));
    } catch (error) {
      return document.cookie.indexOf(storageKey + '=') !== -1;
    }
  }

  if (banner && !hasCookieChoice()) {
    banner.hidden = false;
    setGlassOverlay(true);
  }
  if (accept) accept.addEventListener('click', function () { setCookieChoice('accepted'); });
  if (decline) decline.addEventListener('click', function () { setCookieChoice('declined'); });
  if (settings && banner) {
    settings.addEventListener('click', function () {
      if (banner.hidden) setGlassOverlay(true);
      banner.classList.remove('is-closing');
      banner.hidden = false;
      banner.querySelector('button').focus();
    });
  }
})();
